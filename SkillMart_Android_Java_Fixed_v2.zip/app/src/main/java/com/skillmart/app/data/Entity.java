package com.skillmart.app.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")
public class UserEntity {
    @PrimaryKey(autoGenerate = true) public int id;
    public String name;
    public String email;
    public String password;
    public String bio;
    public String skills;
    public String categories;

    public UserEntity(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.bio = "";
        this.skills = "";
        this.categories = "";
    }
}
