package com.skillmart.app.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "jobs")
public class JobEntity {
    @PrimaryKey(autoGenerate = true) public int id;
    public int posterId;
    public String title;
    public String category;
    public double minBudget;
    public double maxBudget;
    public String deadline;
    public String description;
    public String status; // BIDDING, RUNNING, DELIVERED, COMPLETED

    public JobEntity(int posterId, String title, String category, double minBudget,
                     double maxBudget, String deadline, String description) {
        this.posterId = posterId;
        this.title = title;
        this.category = category;
        this.minBudget = minBudget;
        this.maxBudget = maxBudget;
        this.deadline = deadline;
        this.description = description;
        this.status = "BIDDING";
    }
}
