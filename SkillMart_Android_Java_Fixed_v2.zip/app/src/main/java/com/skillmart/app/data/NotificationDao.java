package com.skillmart.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface NotificationDao {
    @Insert long insert(NotificationEntity n);
    @Query("SELECT * FROM notifications WHERE userId=:userId ORDER BY createdAt DESC")
    List<NotificationEntity> forUser(int userId);
    @Query("SELECT COUNT(*) FROM notifications WHERE userId=:userId AND isRead=0")
    int unread(int userId);
}
