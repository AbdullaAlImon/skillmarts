package com.skillmart.app.data;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {UserEntity.class, JobEntity.class, BidEntity.class,
        CategoryEntity.class, MessageEntity.class, NotificationEntity.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract UserDao userDao();
    public abstract JobDao jobDao();
    public abstract BidDao bidDao();
    public abstract CategoryDao categoryDao();
    public abstract MessageDao messageDao();
    public abstract NotificationDao notificationDao();

    private static volatile AppDatabase INSTANCE;
    public static AppDatabase get(Context c) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null)
                    INSTANCE = Room.databaseBuilder(c.getApplicationContext(),
                            AppDatabase.class, "skillmart.db").allowMainThreadQueries().build();
            }
        }
        return INSTANCE;
    }
}
