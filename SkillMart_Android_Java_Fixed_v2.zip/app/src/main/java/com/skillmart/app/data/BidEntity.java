package com.skillmart.app.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "bids")
public class BidEntity {
    @PrimaryKey(autoGenerate = true) public int id;
    public int jobId;
    public int providerId;
    public double amount;
    public String coverMessage;
    public String status; // PENDING, ACCEPTED, REJECTED

    public BidEntity(int jobId, int providerId, double amount, String coverMessage) {
        this.jobId = jobId;
        this.providerId = providerId;
        this.amount = amount;
        this.coverMessage = coverMessage;
        this.status = "PENDING";
    }
}
