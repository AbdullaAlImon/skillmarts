package com.skillmart.app.ui;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.skillmart.app.Session;
import com.skillmart.app.data.AppDatabase;

public abstract class BaseActivity extends AppCompatActivity {
    protected AppDatabase db;
    protected int uid;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        db = AppDatabase.get(this);
        uid = Session.userId(this);
    }
    protected void requireLogin() {
        if (!Session.loggedIn(this)) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }
    }
}
