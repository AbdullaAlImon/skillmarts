package com.skillmart.app.ui;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import com.skillmart.app.data.*;
import com.skillmart.app.databinding.ActivityAddJobBinding;
import java.util.ArrayList;
import java.util.List;

public class AddJobActivity extends BaseActivity {
    ActivityAddJobBinding b;
    @Override protected void onCreate(Bundle s){
        super.onCreate(s);requireLogin();b=ActivityAddJobBinding.inflate(getLayoutInflater());setContentView(b.getRoot());loadCats();
        b.post.setOnClickListener(v->post());
    }
    void loadCats(){
        List<String> a=new ArrayList<>();for(CategoryEntity c:db.categoryDao().all())a.add(c.name);
        b.category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,a));
    }
    void post(){
        try{
            String title=b.title.getText().toString().trim(), newCat=b.newCategory.getText().toString().trim();
            String cat=newCat.isEmpty()?String.valueOf(b.category.getSelectedItem()):newCat;
            if(!newCat.isEmpty()&&db.categoryDao().count(newCat)==0)db.categoryDao().insert(new CategoryEntity(newCat));
            double min=Double.parseDouble(b.min.getText().toString()), max=Double.parseDouble(b.max.getText().toString());
            if(title.isEmpty()||max<min){toast("Check title and budget");return;}
            db.jobDao().insert(new JobEntity(uid,title,cat,min,max,b.deadline.getText().toString(),b.description.getText().toString()));
            toast("Job published");finish();
        }catch(Exception e){toast("Please complete the required fields");}
    }
    void toast(String x){Toast.makeText(this,x,Toast.LENGTH_SHORT).show();}
}
