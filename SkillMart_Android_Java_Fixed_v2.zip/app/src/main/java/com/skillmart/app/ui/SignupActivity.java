package com.skillmart.app.ui;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import com.skillmart.app.Session;
import com.skillmart.app.data.UserEntity;
import com.skillmart.app.databinding.ActivitySignupBinding;

public class SignupActivity extends BaseActivity {
    ActivitySignupBinding b;
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s); b=ActivitySignupBinding.inflate(getLayoutInflater()); setContentView(b.getRoot());
        b.signup.setOnClickListener(v -> {
            String n=b.name.getText().toString().trim(), e=b.email.getText().toString().trim(), p=b.password.getText().toString();
            if(n.isEmpty()||e.isEmpty()||p.length()<4){toast("Fill all fields; password must be 4+ characters");return;}
            if(db.userDao().findByEmail(e)!=null){toast("Email already registered");return;}
            long id=db.userDao().insert(new UserEntity(n,e,p)); Session.login(this,(int)id);
            startActivity(new Intent(this, MainActivity.class)); finish();
        });
    }
    private void toast(String x){Toast.makeText(this,x,Toast.LENGTH_SHORT).show();}
}
