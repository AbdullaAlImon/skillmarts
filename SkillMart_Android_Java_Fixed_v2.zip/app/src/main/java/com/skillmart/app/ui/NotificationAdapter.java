package com.skillmart.app.ui;

import android.view.*;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.skillmart.app.R;
import com.skillmart.app.data.NotificationEntity;
import java.text.DateFormat;
import java.util.*;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.VH> {
    final List<NotificationEntity> data;
    NotificationAdapter(List<NotificationEntity> d){data=d;}
    public VH onCreateViewHolder(ViewGroup p,int t){
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_notification,p,false));
    }
    public void onBindViewHolder(VH h,int i){
        NotificationEntity n=data.get(i);
        h.title.setText(n.title);
        h.message.setText(n.message);
        h.time.setText(DateFormat.getDateTimeInstance().format(new Date(n.createdAt)));
    }
    public int getItemCount(){return data.size();}
    static class VH extends RecyclerView.ViewHolder{
        TextView title,message,time;
        VH(View v){super(v);title=v.findViewById(R.id.title);message=v.findViewById(R.id.message);time=v.findViewById(R.id.time);}
    }
}
