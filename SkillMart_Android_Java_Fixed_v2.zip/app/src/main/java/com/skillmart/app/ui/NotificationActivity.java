package com.skillmart.app.ui;

import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.skillmart.app.data.NotificationEntity;
import com.skillmart.app.databinding.ActivityNotificationsBinding;
import java.util.List;

public class NotificationActivity extends BaseActivity {
    ActivityNotificationsBinding b;
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        requireLogin();
        b=ActivityNotificationsBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        b.list.setLayoutManager(new LinearLayoutManager(this));
        load();
    }
    void load() {
        List<NotificationEntity> data=db.notificationDao().forUser(uid);
        b.list.setAdapter(new NotificationAdapter(data));
    }
}
