package com.skillmart.app.ui;
import android.content.*;
import android.os.Bundle;
import android.widget.Toast;
import com.skillmart.app.data.UserEntity;
import com.skillmart.app.Session;
import com.skillmart.app.databinding.ActivityProfileBinding;

public class ProfileActivity extends BaseActivity {
 ActivityProfileBinding b;UserEntity u;
 @Override protected void onCreate(Bundle s){super.onCreate(s);requireLogin();b=ActivityProfileBinding.inflate(getLayoutInflater());setContentView(b.getRoot());u=db.userDao().findById(uid);
  b.name.setText(u.name);b.bio.setText(u.bio);b.skills.setText(u.skills);b.categories.setText(u.categories);
  b.save.setOnClickListener(v->{u.name=b.name.getText().toString().trim();u.bio=b.bio.getText().toString();u.skills=b.skills.getText().toString();u.categories=b.categories.getText().toString();db.userDao().update(u);Toast.makeText(this,"Profile saved. You now appear in the Service Directory.",Toast.LENGTH_LONG).show();});
  b.myPosts.setOnClickListener(v->startActivity(new Intent(this,MyPostsActivity.class)));
  b.logout.setOnClickListener(v->{Session.logout(this);startActivity(new Intent(this,MainActivity.class));finish();});
 }
}
