package com.skillmart.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface BidDao {
    @Insert long insert(BidEntity b);
    @Query("SELECT * FROM bids WHERE jobId=:jobId ORDER BY id DESC")
    List<BidEntity> forJob(int jobId);
    @Query("SELECT * FROM bids WHERE jobId=:jobId AND providerId=:providerId LIMIT 1")
    BidEntity existing(int jobId, int providerId);
    @Update void update(BidEntity b);
    @Query("UPDATE bids SET status='REJECTED' WHERE jobId=:jobId AND id!=:acceptedId")
    void rejectOthers(int jobId, int acceptedId);
}
