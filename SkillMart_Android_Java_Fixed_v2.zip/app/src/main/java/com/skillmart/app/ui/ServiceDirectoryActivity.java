package com.skillmart.app.ui;

import android.content.*;
import android.os.Bundle;
import android.text.*;
import android.widget.ArrayAdapter;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.skillmart.app.data.*;
import com.skillmart.app.databinding.ActivityServicesBinding;
import java.util.*;

public class ServiceDirectoryActivity extends BaseActivity {
    ActivityServicesBinding b;
    List<UserEntity> all=new ArrayList<>();
    String selected="All Categories";

    @Override protected void onCreate(Bundle s){
        super.onCreate(s); requireLogin();
        b=ActivityServicesBinding.inflate(getLayoutInflater());setContentView(b.getRoot());

        b.list.setLayoutManager(new LinearLayoutManager(this));
        all=db.userDao().providers();

        List<String> cats=new ArrayList<>(); cats.add("All Categories");
        for(CategoryEntity c:db.categoryDao().all()) cats.add(c.name);
        b.filter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats));
        b.filter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,android.view.View v,int pos,long id){
                selected=String.valueOf(p.getItemAtPosition(pos)); filter(b.search.getText().toString());
            }
        });

        load(all);
        b.profileSetup.setOnClickListener(v->startActivity(new Intent(this,ProfileActivity.class)));
        b.search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b2,int c){filter(s.toString());}
            public void afterTextChanged(Editable e){}
        });
    }

    void filter(String q){
        List<UserEntity>x=new ArrayList<>();
        for(UserEntity u:all){
            boolean text=(u.name+" "+u.skills+" "+u.categories).toLowerCase().contains(q.toLowerCase());
            boolean cat=selected.equals("All Categories") ||
                    u.categories.toLowerCase().contains(selected.toLowerCase());
            if(text&&cat&&u.id!=uid)x.add(u);
        }
        load(x);
    }
    void load(List<UserEntity>x){b.list.setAdapter(new ProviderAdapter(x,u->{
        Intent i=new Intent(this,ChatActivity.class);i.putExtra("otherId",u.id);startActivity(i);
    }));}
    @Override protected void onResume(){super.onResume();if(b!=null){all=db.userDao().providers();filter(b.search.getText().toString());}}
}
