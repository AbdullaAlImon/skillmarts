package com.skillmart.app.ui;
import android.os.Bundle;
import android.widget.Toast;
import com.skillmart.app.data.*;
import com.skillmart.app.databinding.ActivityBidBinding;

public class BidActivity extends BaseActivity {
    ActivityBidBinding b; JobEntity job;
    @Override protected void onCreate(Bundle s){
        super.onCreate(s);requireLogin();b=ActivityBidBinding.inflate(getLayoutInflater());setContentView(b.getRoot());
        job=db.jobDao().byId(getIntent().getIntExtra("jobId",-1));b.jobTitle.setText(job.title);
        b.submit.setOnClickListener(v->submit());
    }
    void submit(){
        try{
            double amount=Double.parseDouble(b.amount.getText().toString());
            String msg=b.message.getText().toString().trim();
            if(msg.isEmpty()){toast("Write a cover message");return;}
            if(amount<job.minBudget||amount>job.maxBudget){toast("Bid should be within the budget range");return;}
            if(db.bidDao().existing(job.id,uid)!=null){toast("You already placed a bid");return;}
            db.bidDao().insert(new BidEntity(job.id,uid,amount,msg));
            db.notificationDao().insert(new NotificationEntity(job.posterId,"New Bid","A new bid was placed on: "+job.title));
            toast("Bid submitted");finish();
        }catch(Exception e){toast("Enter a valid bid amount");}
    }
    void toast(String x){Toast.makeText(this,x,Toast.LENGTH_SHORT).show();}
}
