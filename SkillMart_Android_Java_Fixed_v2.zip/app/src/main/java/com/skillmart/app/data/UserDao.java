package com.skillmart.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface UserDao {
    @Insert long insert(UserEntity u);
    @Query("SELECT * FROM users WHERE email=:email AND password=:password LIMIT 1")
    UserEntity login(String email, String password);
    @Query("SELECT * FROM users WHERE email=:email LIMIT 1")
    UserEntity findByEmail(String email);
    @Query("SELECT * FROM users WHERE id=:id LIMIT 1")
    UserEntity findById(int id);
    @Query("SELECT * FROM users WHERE skills!='' OR categories!=''")
    List<UserEntity> providers();
    @Update void update(UserEntity u);
}
