package com.skillmart.app.ui;

import android.content.Intent;
import android.os.Bundle;
import com.skillmart.app.R;
import com.skillmart.app.Seed;
import com.skillmart.app.Session;
import com.skillmart.app.databinding.ActivityMainBinding;

public class MainActivity extends BaseActivity {
    ActivityMainBinding b;
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        b=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        Seed.run(this);

        b.marketBtn.setOnClickListener(v -> startActivity(new Intent(this, MarketplaceActivity.class)));
        b.serviceBtn.setOnClickListener(v -> { if(!Session.loggedIn(this)) startActivity(new Intent(this,LoginActivity.class));
            else startActivity(new Intent(this,ServiceDirectoryActivity.class)); });
        b.postsBtn.setOnClickListener(v -> { if(!Session.loggedIn(this)) startActivity(new Intent(this,LoginActivity.class));
            else startActivity(new Intent(this,MyPostsActivity.class)); });
        b.notificationBtn.setOnClickListener(v -> { if(!Session.loggedIn(this)) startActivity(new Intent(this,LoginActivity.class));
            else startActivity(new Intent(this,NotificationActivity.class)); });
        b.profileBtn.setOnClickListener(v -> { if(!Session.loggedIn(this)) startActivity(new Intent(this,LoginActivity.class));
            else startActivity(new Intent(this,ProfileActivity.class)); });
        b.loginBtn.setOnClickListener(v -> startActivity(new Intent(this,
                Session.loggedIn(this) ? ProfileActivity.class : LoginActivity.class)));
    }
}
