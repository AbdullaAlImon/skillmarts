package com.skillmart.app;

import android.content.Context;

public class Session {
    private static final String PREF = "skillmart_session";
    public static void login(Context c, int id) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt("userId", id).apply();
    }
    public static int userId(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt("userId", -1);
    }
    public static boolean loggedIn(Context c) { return userId(c) != -1; }
    public static void logout(Context c) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply();
    }
}
