package com.skillmart.app.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "notifications")
public class NotificationEntity {
    @PrimaryKey(autoGenerate = true) public int id;
    public int userId;
    public String title;
    public String message;
    public long createdAt;
    public boolean isRead;

    public NotificationEntity(int userId, String title, String message) {
        this.userId = userId;
        this.title = title;
        this.message = message;
        this.createdAt = System.currentTimeMillis();
        this.isRead = false;
    }
}
