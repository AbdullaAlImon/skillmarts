package com.skillmart.app.ui;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import com.skillmart.app.Session;
import com.skillmart.app.databinding.ActivityLoginBinding;

public class LoginActivity extends BaseActivity {
    ActivityLoginBinding b;
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s); b=ActivityLoginBinding.inflate(getLayoutInflater()); setContentView(b.getRoot());
        b.login.setOnClickListener(v -> {
            String e=b.email.getText().toString().trim(), p=b.password.getText().toString();
            UserLogin(e,p);
        });
        b.signup.setOnClickListener(v -> startActivity(new Intent(this, SignupActivity.class)));
    }
    private void UserLogin(String e,String p){
        if(e.isEmpty()||p.isEmpty()){toast("Enter email and password");return;}
        var u=db.userDao().login(e,p);
        if(u==null) toast("Invalid email or password");
        else { Session.login(this,u.id); startActivity(new Intent(this, MainActivity.class)); finish(); }
    }
    private void toast(String x){Toast.makeText(this,x,Toast.LENGTH_SHORT).show();}
}
