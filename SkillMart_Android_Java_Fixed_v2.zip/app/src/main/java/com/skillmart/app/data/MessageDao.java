package com.skillmart.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface MessageDao {
    @Insert long insert(MessageEntity m);
    @Query("SELECT * FROM messages WHERE (senderId=:a AND receiverId=:b) OR (senderId=:b AND receiverId=:a) ORDER BY sentAt ASC")
    List<MessageEntity> conversation(int a, int b);
}
