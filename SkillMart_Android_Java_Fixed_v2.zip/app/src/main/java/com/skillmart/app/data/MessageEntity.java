package com.skillmart.app.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "messages")
public class MessageEntity {
    @PrimaryKey(autoGenerate = true) public int id;
    public int senderId;
    public int receiverId;
    public String text;
    public long sentAt;

    public MessageEntity(int senderId, int receiverId, String text) {
        this.senderId = senderId;
        this.receiverId = receiverId;
        this.text = text;
        this.sentAt = System.currentTimeMillis();
    }
}
