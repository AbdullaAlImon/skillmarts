package com.skillmart.app;

import android.content.Context;
import com.skillmart.app.data.*;

public class Seed {
    public static void run(Context c) {
        AppDatabase db = AppDatabase.get(c);
        String[] cats = {"Web Development","App Development","Graphic Design","Writing",
                "Video Editing","Digital Marketing","Data Entry","Tutoring"};
        for (String s : cats) if (db.categoryDao().count(s) == 0) db.categoryDao().insert(new CategoryEntity(s));
    }
}
