package com.skillmart.app.ui;
import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import com.skillmart.app.R;
import com.skillmart.app.data.UserEntity;
import java.util.List;
import java.util.function.Consumer;

public class ProviderAdapter extends RecyclerView.Adapter<ProviderAdapter.VH>{
 List<UserEntity>d;Consumer<UserEntity>click;ProviderAdapter(List<UserEntity>x,Consumer<UserEntity>c){d=x;click=c;}
 public VH onCreateViewHolder(ViewGroup p,int t){return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_provider,p,false));}
 public void onBindViewHolder(VH h,int i){UserEntity u=d.get(i);h.name.setText(u.name);h.skills.setText("Skills: "+u.skills+"\nCategories: "+u.categories);h.chat.setOnClickListener(v->click.accept(u));}
 public int getItemCount(){return d.size();}
 static class VH extends RecyclerView.ViewHolder{TextView name,skills;Button chat;VH(View v){super(v);name=v.findViewById(R.id.name);skills=v.findViewById(R.id.skills);chat=v.findViewById(R.id.chat);}}
}
