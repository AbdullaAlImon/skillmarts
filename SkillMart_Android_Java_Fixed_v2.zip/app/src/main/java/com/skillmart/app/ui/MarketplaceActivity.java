package com.skillmart.app.ui;
import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.skillmart.app.data.JobEntity;
import com.skillmart.app.databinding.ActivityMarketplaceBinding;
import java.util.List;

public class MarketplaceActivity extends BaseActivity {
    ActivityMarketplaceBinding b;
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s); b=ActivityMarketplaceBinding.inflate(getLayoutInflater()); setContentView(b.getRoot());
        b.list.setLayoutManager(new LinearLayoutManager(this)); load();
        b.addJob.setOnClickListener(v -> { requireLogin(); startActivity(new Intent(this, AddJobActivity.class)); });
    }
    void load(){ List<JobEntity> jobs=db.jobDao().active(); b.list.setAdapter(new JobAdapter(jobs, j -> { Intent i=new Intent(this,JobDetailsActivity.class);i.putExtra("jobId",j.id);startActivity(i);}));}
    @Override protected void onResume(){super.onResume(); if(b!=null)load();}
}
