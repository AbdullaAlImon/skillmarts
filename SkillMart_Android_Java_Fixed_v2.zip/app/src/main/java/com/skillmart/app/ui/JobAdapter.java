package com.skillmart.app.ui;
import android.view.*;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.skillmart.app.R;
import com.skillmart.app.data.JobEntity;
import java.util.List;
import java.util.function.Consumer;

public class JobAdapter extends RecyclerView.Adapter<JobAdapter.VH>{
    List<JobEntity> data; Consumer<JobEntity> click;
    JobAdapter(List<JobEntity>d,Consumer<JobEntity>c){data=d;click=c;}
    public VH onCreateViewHolder(ViewGroup p,int t){return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_job,p,false));}
    public void onBindViewHolder(VH h,int pos){JobEntity j=data.get(pos);h.title.setText(j.title);h.cat.setText("Category: "+j.category);h.budget.setText(String.format("Budget: $%.2f - $%.2f",j.minBudget,j.maxBudget));h.dead.setText("Deadline: "+j.deadline);h.status.setText("Status: "+j.status);h.itemView.setOnClickListener(v->click.accept(j));}
    public int getItemCount(){return data.size();}
    static class VH extends RecyclerView.ViewHolder{TextView title,cat,budget,dead,status;VH(View v){super(v);title=v.findViewById(R.id.title);cat=v.findViewById(R.id.category);budget=v.findViewById(R.id.budget);dead=v.findViewById(R.id.deadline);status=v.findViewById(R.id.status);}}
}
