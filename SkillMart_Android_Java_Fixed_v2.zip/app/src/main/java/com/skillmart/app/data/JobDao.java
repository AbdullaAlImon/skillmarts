package com.skillmart.app.data;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface JobDao {
    @Insert long insert(JobEntity j);
    @Query("SELECT * FROM jobs WHERE status IN ('BIDDING','RUNNING','DELIVERED') ORDER BY id DESC")
    List<JobEntity> active();
    @Query("SELECT * FROM jobs WHERE posterId=:userId ORDER BY id DESC")
    List<JobEntity> myPosts(int userId);
    @Query("SELECT * FROM jobs WHERE id=:id LIMIT 1")
    JobEntity byId(int id);
    @Update void update(JobEntity j);
    @Delete void delete(JobEntity j);
}
