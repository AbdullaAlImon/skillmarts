package com.skillmart.app.ui;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.ScrollView;
import com.skillmart.app.R;
import com.skillmart.app.data.*;
import com.skillmart.app.databinding.ActivityChatBinding;

public class ChatActivity extends BaseActivity {
 ActivityChatBinding b;int other;
 @Override protected void onCreate(Bundle s){super.onCreate(s);requireLogin();b=ActivityChatBinding.inflate(getLayoutInflater());setContentView(b.getRoot());other=getIntent().getIntExtra("otherId",-1);
  UserEntity u=db.userDao().findById(other);b.header.setText("Chat • "+(u==null?"User":u.name));load();
  b.send.setOnClickListener(v->{String t=b.input.getText().toString().trim();if(!t.isEmpty()){db.messageDao().insert(new MessageEntity(uid,other,t));b.input.setText("");load();}});
 }
 void load(){b.messages.removeAllViews();for(MessageEntity m:db.messageDao().conversation(uid,other)){TextView tv=new TextView(this);tv.setText(m.text);tv.setTextSize(16);tv.setPadding(14,10,14,10);tv.setGravity(m.senderId==uid?Gravity.END:Gravity.START);b.messages.addView(tv);}b.scroll.post(()->b.scroll.fullScroll(ScrollView.FOCUS_DOWN));}
}
