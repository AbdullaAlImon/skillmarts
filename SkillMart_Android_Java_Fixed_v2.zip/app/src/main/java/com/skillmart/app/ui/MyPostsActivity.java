package com.skillmart.app.ui;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.*;
import com.skillmart.app.data.*;
import com.skillmart.app.databinding.ActivityMyPostsBinding;
import java.util.List;

public class MyPostsActivity extends BaseActivity {
    ActivityMyPostsBinding b;

    @Override protected void onCreate(Bundle s){
        super.onCreate(s); requireLogin();
        b=ActivityMyPostsBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot()); load();
    }

    void load(){
        List<JobEntity> jobs=db.jobDao().myPosts(uid);
        b.list.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(this));
        b.list.setAdapter(new JobAdapter(jobs,this::showJobActions));
    }

    void showJobActions(JobEntity j){
        if("DELIVERED".equals(j.status)){
            new AlertDialog.Builder(this)
                .setTitle("Confirm Completion")
                .setMessage("The provider has marked this job as delivered. Confirm to complete the job?")
                .setPositiveButton("Confirm Completion",(d,w)->confirmCompletion(j))
                .setNegativeButton("Cancel",null).show();
            return;
        }

        if("COMPLETED".equals(j.status)){
            BidEntity a=findAccepted(j.id);
            String provider=a==null?"Unknown provider":safeName(a.providerId);
            new AlertDialog.Builder(this).setTitle(j.title)
                .setMessage("Status: Completed\nService provider: "+provider)
                .setPositiveButton("Delete Post",(d,w)->deletePost(j))
                .setNegativeButton("Close",null).show();
            return;
        }

        List<BidEntity> bids=db.bidDao().forJob(j.id);
        String[] items=new String[bids.size()+1];
        for(int i=0;i<bids.size();i++){
            BidEntity x=bids.get(i);
            items[i]=safeName(x.providerId)+" — $"+String.format("%.2f",x.amount)+" ["+x.status+"]\n"+x.coverMessage;
        }
        items[bids.size()]="Delete this post";

        new AlertDialog.Builder(this).setTitle(j.title+" • Bids")
            .setItems(items,(d,which)->{
                if(which==bids.size()){deletePost(j);return;}
                BidEntity x=bids.get(which);
                if(!"PENDING".equals(x.status))return;
                new AlertDialog.Builder(this).setTitle("Accept this bid?")
                    .setMessage("Accept "+safeName(x.providerId)+" for $"+x.amount+"?\nAll other bids will be rejected.")
                    .setPositiveButton("Accept",(a,w)->accept(j,x))
                    .setNegativeButton("Cancel",null).show();
            }).setNegativeButton("Close",null).show();
    }

    String safeName(int id){UserEntity u=db.userDao().findById(id);return u==null?"Provider":u.name;}

    BidEntity findAccepted(int id){
        for(BidEntity x:db.bidDao().forJob(id)) if("ACCEPTED".equals(x.status)) return x;
        return null;
    }

    void accept(JobEntity j,BidEntity x){
        x.status="ACCEPTED"; db.bidDao().update(x); db.bidDao().rejectOthers(j.id,x.id);
        j.status="RUNNING"; db.jobDao().update(j);
        db.notificationDao().insert(new NotificationEntity(x.providerId,"Bid Accepted",
                "Your bid for \""+j.title+"\" was accepted."));
        Toast.makeText(this,"Bid accepted. Other bids rejected.",Toast.LENGTH_LONG).show();
        load();
    }

    void confirmCompletion(JobEntity j){
        j.status="COMPLETED"; db.jobDao().update(j);
        BidEntity a=findAccepted(j.id);
        if(a!=null) db.notificationDao().insert(new NotificationEntity(a.providerId,"Job Completed",
                "The poster confirmed completion of \""+j.title+"\"."));
        Toast.makeText(this,"Job marked as Completed.",Toast.LENGTH_LONG).show();
        load();
    }

    void deletePost(JobEntity j){
        db.jobDao().delete(j);
        Toast.makeText(this,"Post deleted.",Toast.LENGTH_SHORT).show();
        load();
    }

    @Override protected void onResume(){super.onResume();if(b!=null)load();}
}
