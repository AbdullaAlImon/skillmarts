package com.skillmart.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface CategoryDao {
    @Insert long insert(CategoryEntity c);
    @Query("SELECT * FROM categories ORDER BY name ASC")
    List<CategoryEntity> all();
    @Query("SELECT COUNT(*) FROM categories WHERE lower(name)=lower(:name)")
    int count(String name);
}
