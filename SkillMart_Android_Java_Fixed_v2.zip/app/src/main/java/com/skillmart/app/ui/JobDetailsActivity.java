package com.skillmart.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import com.skillmart.app.data.*;
import com.skillmart.app.databinding.ActivityJobDetailsBinding;

public class JobDetailsActivity extends BaseActivity {
    ActivityJobDetailsBinding b;
    JobEntity job;

    @Override protected void onCreate(Bundle s){
        super.onCreate(s);
        b=ActivityJobDetailsBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());

        int id=getIntent().getIntExtra("jobId",-1);
        job=db.jobDao().byId(id);
        if(job==null){finish();return;}

        b.title.setText(job.title);
        b.meta.setText("Category: "+job.category+"   |   Budget: $"+job.minBudget+" - $"+job.maxBudget
                +"   |   Deadline: "+job.deadline+"\nStatus: "+job.status);
        b.desc.setText(job.description);

        if("BIDDING".equals(job.status)) {
            b.bid.setText("Place a Bid");
            b.bid.setOnClickListener(v->{requireLogin();Intent i=new Intent(this,BidActivity.class);
                i.putExtra("jobId",job.id);startActivity(i);});
        } else if("RUNNING".equals(job.status)) {
            BidEntity accepted=findAccepted(job.id);
            if(accepted!=null && accepted.providerId==uid) {
                b.bid.setText("Mark Work as Delivered");
                b.bid.setOnClickListener(v->deliver(accepted));
            } else {
                b.bid.setText("Work in Progress");
                b.bid.setEnabled(false);
            }
        } else if("DELIVERED".equals(job.status)) {
            b.bid.setText("Waiting for Completion Confirmation");
            b.bid.setEnabled(false);
        } else {
            b.bid.setText("Completed");
            b.bid.setEnabled(false);
        }
    }

    BidEntity findAccepted(int jobId){
        for(BidEntity b:db.bidDao().forJob(jobId)) if("ACCEPTED".equals(b.status)) return b;
        return null;
    }

    void deliver(BidEntity accepted){
        job.status="DELIVERED";
        db.jobDao().update(job);
        db.notificationDao().insert(new NotificationEntity(job.posterId,"Work Delivered",
                "The service provider delivered work for \""+job.title+"\". Please confirm completion."));
        Toast.makeText(this,"Marked as delivered.",Toast.LENGTH_LONG).show();
        finish();
    }
}
