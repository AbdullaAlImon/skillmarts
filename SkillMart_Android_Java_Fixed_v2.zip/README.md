# SkillMart — Offline-First Android App

SkillMart is a Java Android Studio peer-to-peer service marketplace. One local account can post jobs, bid on jobs, provide services, chat, and manage work.

## Confirmed scope
- Java
- Room Database / SQLite
- Email + password local authentication
- No real payment integration
- Text-only local chat
- Bid-based pricing (no hourly rate)
- User-created categories are shared in the job category list
- Workflow: Posted/Bidding → Running → Delivered → Completed
- Accepting one bid automatically rejects all other bids
- Local notifications for important workflow events
- Provider profile with name, bio, skills and categories
- SkillMart logo supplied by the project owner

## Open/Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on an Android emulator/device (API 24+).
4. The first run seeds the default service categories.

## Important next implementation step
The current project includes the core database, marketplace workflow, messaging, profile, categories and notifications. The following polish items can be extended:
- Material bottom navigation matching the supplied references
- Notification unread badge (notification list is included)
- Full bid cards can replace the compact action dialog
- Delivered + Confirm Completion actions are included
- Search/category filter controls are included
- More polished cards, spacing and icons matching the reference UI
- Sample demo data for presentation/viva
